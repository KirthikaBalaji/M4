﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using RechargeDetails_WebAPI;

namespace RechargeDetails_WebAPI.Controllers
{
    public class RechargeDetailsController : ApiController
    {
        private Training_19Sep19_PuneEntities db = new Training_19Sep19_PuneEntities();

        // GET: api/RechargeDetails
        public IQueryable<RechargeDetail> GetRechargeDetails()
        {
            return db.RechargeDetails;
        }

        // GET: api/RechargeDetails/5
        [ResponseType(typeof(RechargeDetail))]
        public IHttpActionResult GetRechargeDetail(string id)
        {
            RechargeDetail rechargeDetail = db.RechargeDetails.Find(id);
            if (rechargeDetail == null)
            {
                return NotFound();
            }

            return Ok(rechargeDetail);
        }

        // PUT: api/RechargeDetails/5
        [ResponseType(typeof(void))]
        public IHttpActionResult PutRechargeDetail(string id, RechargeDetail rechargeDetail)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != rechargeDetail.TransactionId)
            {
                return BadRequest();
            }

            db.Entry(rechargeDetail).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!RechargeDetailExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/RechargeDetails
        [ResponseType(typeof(RechargeDetail))]
        public IHttpActionResult PostRechargeDetail(RechargeDetail rechargeDetail)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.RechargeDetails.Add(rechargeDetail);

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateException)
            {
                if (RechargeDetailExists(rechargeDetail.TransactionId))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtRoute("DefaultApi", new { id = rechargeDetail.TransactionId }, rechargeDetail);
        }

        // DELETE: api/RechargeDetails/5
        [ResponseType(typeof(RechargeDetail))]
        public IHttpActionResult DeleteRechargeDetail(string id)
        {
            RechargeDetail rechargeDetail = db.RechargeDetails.Find(id);
            if (rechargeDetail == null)
            {
                return NotFound();
            }

            db.RechargeDetails.Remove(rechargeDetail);
            db.SaveChanges();

            return Ok(rechargeDetail);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool RechargeDetailExists(string id)
        {
            return db.RechargeDetails.Count(e => e.TransactionId == id) > 0;
        }
    }
}
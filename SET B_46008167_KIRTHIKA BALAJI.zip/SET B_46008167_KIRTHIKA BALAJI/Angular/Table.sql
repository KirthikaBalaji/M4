USE [Training_19Sep19_Pune]
GO

/****** Object:  Table [46008167].[RechargeDetails]    Script Date: 11/21/2019 11:47:01 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [46008167].[RechargeDetails](
	[TransactionId] [varchar](10) NOT NULL,
	[MobileNumber] [varchar](10) NULL,
	[RechargeDateTime] [datetime] NULL,
	[RechargeCatergory] [varchar](20) NULL,
	[RechargeAmount] [real] NULL,
	[AdditionalDetails] [varchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[TransactionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO



import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms'

import { AppComponent }  from './app.component';
import { RechargeComponent } from './recharge.component';
import { HttpClientModule } from '@angular/common/http';
import { RechargetHttpService } from './recharge.service';
import { RechargePipe } from './recharge.filter';



@NgModule({
  imports:      [ BrowserModule,HttpClientModule,FormsModule],
  declarations: [ AppComponent,RechargeComponent,RechargePipe ],
  bootstrap:    [ RechargeComponent],
  providers:[RechargetHttpService]
})
export class AppModule { }

import { Component } from "@angular/core";

@Component({
    selector:'my-app',
    template:`<h2>Welcome to Angular</h2>`
})
export class AppComponent{

}
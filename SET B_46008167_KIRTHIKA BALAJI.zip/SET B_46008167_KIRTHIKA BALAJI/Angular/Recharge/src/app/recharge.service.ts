import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { IRecharge } from './IRecharge';

@Injectable()
export class RechargetHttpService {
    constructor(private httpClient: HttpClient) { }
    
    getRecharges():Observable<IRecharge[]>{
        return this.httpClient.get<IRecharge[]>('http://localhost:57764/api/RechargeDetails')
}
}
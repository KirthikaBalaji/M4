import { Pipe, PipeTransform } from '@angular/core';
import { IRecharge } from './IRecharge';

@Pipe({
    name: 'rechargepipe'
})

export class RechargePipe implements PipeTransform {
    transform(value:IRecharge[],searchString:string): any {
        searchString=searchString?searchString.toLowerCase():null;
        return searchString? value.filter((recharge: IRecharge)=>recharge.MobileNumber.toLowerCase().indexOf(searchString)!==-1):value  
        
    }
}
export interface IRecharge
{
    RechargeId :string
    MobileNumber:string
    RechargeDateTime:Date
    RechargeCatergory:string
    RechargeAmount:string
    AdditionalDetails:string
     
}
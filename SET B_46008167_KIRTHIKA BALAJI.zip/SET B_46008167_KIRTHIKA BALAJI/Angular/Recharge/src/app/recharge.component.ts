import { Component, OnInit } from '@angular/core';
import { IRecharge } from './IRecharge';
import { RechargetHttpService } from './recharge.service';

@Component({
    selector: 'recharge',
    templateUrl: './recharge.component.html',
    styleUrls:[`./recharge.component.css`]
})

export class RechargeComponent implements OnInit {

    recharges:IRecharge[];
    constructor(private rechargeHttpService: RechargetHttpService) { }

    ngOnInit() {
        this.rechargeHttpService.getRecharges().subscribe(rech=>this.recharges=rech);
     }
}
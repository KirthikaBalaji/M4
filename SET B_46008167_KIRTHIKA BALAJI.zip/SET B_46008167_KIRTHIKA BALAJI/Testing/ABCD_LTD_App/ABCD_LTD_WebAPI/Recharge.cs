﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ABCD_LTD_WebAPI
{
    public class Recharge
    {
        public string MobileNumber { get; set; }
        public string RechargeCategory { get; set; }
        public double RechargeAmount { get; set; }
        public string Email { get; set; }

        public override string ToString()
        {
            return $"Mobile Number {MobileNumber}<br>Recharge Category {RechargeCategory}<br>Recharge Amount: {RechargeAmount}<br>Email: {Email}";
        }
    }
}
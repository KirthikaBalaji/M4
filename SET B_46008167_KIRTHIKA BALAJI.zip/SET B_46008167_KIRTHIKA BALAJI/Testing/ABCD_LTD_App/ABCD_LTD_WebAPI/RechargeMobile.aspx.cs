﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ABCD_LTD_WebAPI
{
    public partial class RechargeMobile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnRecharge_Click(object sender, EventArgs e)
        {
            Recharge rc = new Recharge
            {
                MobileNumber = txtMobno.Text,              
                RechargeAmount = double.Parse(txtRcAmount.Text),
                Email = txtEmail.Text,
               
        };
            rc.RechargeCategory = listtRcCategory.SelectedValue;

            try
            {
                if (Validate(rc))
                {
                    divDisplay.InnerHtml = rc.ToString();
                    Thread.Sleep(3000);
                    Response.Redirect("~/RechargeSuccess.aspx");
                }

            }
            catch (RechargeException ex)
            {
                divDisplay.InnerHtml = ex.Message;
            }
        }
        public static bool Validate(Recharge rc)
        {
            bool valid = true;

            StringBuilder sb = new StringBuilder();

            if (!Regex.IsMatch(rc.MobileNumber.ToString(), @"^\d{10}$"))
            {
                sb.Append("Mobile should be of 10 digit" + Environment.NewLine);
                valid = false;
            }

            if (rc.RechargeAmount<40 || rc.RechargeAmount > 500)
            {
                sb.Append("Recharge Amount should be from 40 to 500" + Environment.NewLine);
                valid = false;
            }
           
            if (!Regex.IsMatch(rc.Email, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase))
            {
                sb.Append("Email should be of proper format" + Environment.NewLine);
                valid = false;
            }

            if (!(rc.RechargeCategory == "Talktime" || rc.RechargeCategory == "3G 4G Data" ))
            {
                sb.Append("RechargeCatergory should be Talktime or 3G 4G data" + Environment.NewLine);

            }          
            if (!valid)
            {
                throw new RechargeException(sb.ToString());
            }
            return valid;
        }
    }
}
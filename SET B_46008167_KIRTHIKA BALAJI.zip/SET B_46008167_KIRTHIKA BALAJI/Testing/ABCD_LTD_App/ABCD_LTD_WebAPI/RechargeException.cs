﻿using System;
using System.Runtime.Serialization;

namespace ABCD_LTD_WebAPI
{
    [Serializable]
    internal class RechargeException : Exception
    {
        public RechargeException()
        {
        }

        public RechargeException(string message) : base(message)
        {
        }

        public RechargeException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected RechargeException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
﻿using ABCD_LTD_WebAPI;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Threading;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace RechargeMobile_Tests
{
    [Binding]
    
    public class RechargeFeatureSteps
    {
         IWebDriver driver = null;
        [Given(@"Open Google Chrome")]
        public void GivenOpenGoogleChrome()
        {
            driver = new ChromeDriver();
        }
        
        [Given(@"Navigate to Recharge Web App MobileRecharge page")]
        public void GivenNavigateToRechargeWebAppMobileRechargePage()
        {
            driver.Navigate().GoToUrl("http://localhost:60841/RechargeMobile.aspx");
        }
        
        [When(@"Enter data in all fields in  MobileRecharge page")]
        public void WhenEnterDataInAllFieldsInMobileRechargePage(Table table)
        {
            Recharge rc = table.CreateInstance<Recharge>();
            driver.FindElement(By.Id("txtMobno")).SendKeys(rc.MobileNumber.ToString());
            //driver.FindElement(By.Id("listtRcCategory")).FindElement(By.XPath(".//option[contains(text(),'" + rc.RechargeCategory + "')]")).Click();
            driver.FindElement(By.Id("txtRcAmount")).SendKeys(rc.RechargeAmount.ToString());
            driver.FindElement(By.Id("txtEmail")).SendKeys(rc.Email.ToString());                   
        }

        [When(@"I click on Recharge Button")]
        public void WhenIClickOnRechargeButton()
        {
            Thread.Sleep(3000);

            driver.FindElement(By.Id("btnRecharge")).Click();
        }
        
        [When(@"I click on Register Me Button")]
        public void WhenIClickOnRegisterMeButton()
        {
            Thread.Sleep(3000);

            driver.FindElement(By.Id("btnRecharge")).Click();
        }
        
        [Then(@"I Should see Thanks page")]
        public void ThenIShouldSeeThanksPage()
        {
            Assert.IsTrue(driver.Url == "http://localhost:60841/RechargeSuccess.aspx");
        }
        
        [Then(@"Validate All the Fields")]
        public void ThenValidateAllTheFields()
        {
            
                int value = 0;
                var res = driver.FindElement(By.Id("divDisplay")).GetProperty("innerText");
                if (res.Contains("Mobile should be of 10 digit"))
                {
                    value++;
                }
                if (res.Contains("Recharge Amount should be from 40 to 500"))
                {
                    value++;
                }
                if (res.Contains("Email should be of proper format"))
                {
                    value++;
                }
                if (res.Contains("RechargeCatergory should be Talktime or 3G 4G data"))
                {
                    value++;
                }

              
            Assert.AreEqual(4, value);
            }
        }
    }

